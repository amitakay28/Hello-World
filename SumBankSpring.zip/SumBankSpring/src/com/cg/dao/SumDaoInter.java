package com.cg.dao;

import java.util.List;

import com.cg.bean.SumBank;
import com.cg.bean.Transactions;

public interface SumDaoInter {

	public String createAccount(SumBank sum);
	public String viewBalance(long acc);
	public String creditMoney(long acc, long amt);
	public String debitMoney(long acc, long amt);
	public String transferFunds(long sender, long reciver, long amt);
	 public void storeTransaction(String str,int accNo);
	 public List<Transactions> showTransaction(long acc);
	long getBalance(long acc);
	boolean findAccount(long acc);
}
