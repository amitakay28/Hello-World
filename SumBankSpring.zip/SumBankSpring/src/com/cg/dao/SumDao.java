package com.cg.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Order;
import com.cg.bean.SumBank;
import com.cg.bean.Transactions;

@Repository
@Transactional
public class SumDao implements SumDaoInter{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public String createAccount(SumBank sum) {
		
	    em.persist(sum);
		return "Account has been created with account number " + sum.getAccount_number();
	}

	@Override
	public String viewBalance(long acc) {
		SumBank sum = em.find(SumBank.class, acc);
		return "Available balance is " + sum.getBalance();
	}

	@Override
	public String creditMoney(long acc, long amt) {
		SumBank sum = em.find(SumBank.class, acc);
		long update = sum.getBalance() + amt;
		sum.setBalance(update);
		em.flush();
		
		String date = generateDate();
		String str = "Money " + amt + " Deposited at " + date;
		storeTransaction(str,(int)acc);
		
		return "Money Deposited " + amt + " in acc no " + acc ;
	}

	@Override
	public String debitMoney(long acc, long amt) {
		SumBank sum = em.find(SumBank.class, acc);
		long update = sum.getBalance() - amt;
		sum.setBalance(update);
		
		String date = generateDate();
		String str = "Money " + amt + " Debited at " + date;
		storeTransaction(str,(int)acc);
		
		return "Money " + amt + " debited from acc number " + acc;
	}

	@Override
	public String transferFunds(long sender, long reciver, long amt) {
        debitMoney(sender, amt);
        creditMoney(reciver, amt);
        
        String date = generateDate();
		String str = "Money " + amt +" Transferred to Acc: " + reciver + " at " + date;
		String str1 = "Money " + amt +" recieved from Acc: " + sender + " at " + date;
		storeTransaction(str,(int)sender);
		storeTransaction(str1, (int)reciver);
        
		return "Money Deposited " + amt + " in acc no " + reciver + " and " + "Money " + amt + " debited from acc number " + sender;
	}

	@Override
	public void storeTransaction(String str, int accNo) {
		Transactions t = new Transactions(str, accNo);
		em.persist(t);
//		Order order = new Order(103,2003,3);
//		em.persist(order);
	
		
	}
	
	 public String generateDate() {
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	    	LocalDateTime now = LocalDateTime.now();
			String date = dtf.format(now);
			return date;
	 }

	@Override
	public List<Transactions> showTransaction(long acc) {
		
		TypedQuery<Transactions> q = em.createQuery("from Transactions t where t.accNo = :n", Transactions.class);
		q.setParameter("n", (int)acc);
		List<Transactions> li = q.getResultList();
		return li;
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public long getBalance(long acc) {
		SumBank sum = em.find(SumBank.class, acc);
		return sum.getBalance();
	}
	
	@Override
	public boolean findAccount(long acc)
	{
		boolean result;
		SumBank sum = em.find(SumBank.class, acc);
		if(sum == null)
			result = false;
		else
			result = true;
		return result;
	}

}
