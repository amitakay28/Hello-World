
package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bean.SumBank;
import com.cg.bean.Transactions;
import com.cg.service.SumServiceInter;

@Controller
public class SumBankController {

	@Autowired
	SumServiceInter ser;
	
	@RequestMapping("/")
	public String setShow()
	{
		return "index";
	}
	@RequestMapping("/add")
	public String setAdd()
	{
		return "add";
	}
	@RequestMapping("/home")
	public String setHome()
	{
		return "index";
	}
	@RequestMapping("/view")
	public String setView()
	{
		return "view";
	}
	@RequestMapping("/credit")
	public String setCredit()
	{
		return "credit";
	}
	
	@RequestMapping("/debit")
	public String setDebit()
	{
		return "debit";
	}
	@RequestMapping("/transfer")
	public String setTransfer()
	{
		return "transfer";
	}
	@RequestMapping("/transaction")
	public String setTransaction()
	{
		return "transaction";
	}
	
	@RequestMapping("create")
	public String createAccount(@RequestParam("name") String t1, @RequestParam("address")String t2, @RequestParam("dob") String t3, @RequestParam("phoneNumber") long t4,   Model m)
	{
		SumBank sum = new SumBank(t1,t4,t2, t3);
		String msg = ser.createAccount(sum);
		m.addAttribute("msg", msg);
		return "message";
	}
	
	@RequestMapping("check")
	public String checkBalance(@RequestParam("acc") long t1,   Model m)
	{
	
		String msg = ser.viewBalance(t1);
		m.addAttribute("msg", msg);
		return "message";
	}
	
	@RequestMapping("deposit")
	public String depositBalance(@RequestParam("acc") long t1,  @RequestParam("amt") long t2,  Model m)
	{
	
		String msg = ser.creditMoney(t1, t2);
		m.addAttribute("msg", msg);
		return "message";
	}
	@RequestMapping("withdrawal")
	public String debitBalance(@RequestParam("acc") long t1,  @RequestParam("amt") long t2,  Model m)
	{
	
		String msg = ser.debitMoney(t1, t2);
		m.addAttribute("msg", msg);
		return "message";
	}
	@RequestMapping("send")
	public String sendFunds(@RequestParam("sender") long t1,  @RequestParam("reciver") long t2, @RequestParam("amt") long t3,  Model m)
	{
	
		String msg = ser.transferFunds(t1, t2, t3);
		m.addAttribute("msg", msg);
		return "message";
	}
	
	@RequestMapping("history")
	public String showTransaction(@RequestParam("acc") long t1,  Model m)
	{
	
		List<Transactions> li  = ser.showTransaction(t1);
		m.addAttribute("msg", li);
		return "history";
	}
}
