package com.cg.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="sumbankdetails")
public class SumBank {
	@Column(name="Name")
	private String name;
	@Column(name="Address")
	String address;
	@Column(name="DOB")
	String dob;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Account_Number")
	private long account_number;
	@Column(name="Balance")
	private long balance;
	//private long credit;
	@Column(name="Phone_Number")
	long phoneNumber;
	//private long debit;
	SumBank(){}
	public SumBank(String name, long phoneNumber ,String address, String dob) {
		super();
		this.name = name;
		this.phoneNumber = phoneNumber;
		//this.balance = balance;
		this.address = address;
		this.dob = dob;
	}
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public long getAccount_number() {
		return account_number;
	}

	public void setAccount_number(long account_number) {
		this.account_number = account_number;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAccountNumber() {
		return account_number++;
	}
	public void setAccountNumber(long  account_number) {
		this.account_number = account_number;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "SumBank [name=" + name + ", account_number=" + account_number + ", balance=" + balance + ", phoneNumber=" + phoneNumber + "address = "  + address + " date of birth = " + dob + "  ]";
	}
	

	
	

}
