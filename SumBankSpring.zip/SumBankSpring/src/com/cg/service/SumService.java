package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.SumBank;
import com.cg.bean.Transactions;
import com.cg.dao.SumDaoInter;

@Service
public class SumService implements SumServiceInter{

	@Autowired
	SumDaoInter dao;
	@Override
	public String createAccount(SumBank sum) {
	     String msg = dao.createAccount(sum);
		
		return msg;
	}
	@Override
	public String viewBalance(long acc) {
		String msg;
		if(dao.findAccount(acc))
	 msg = dao.viewBalance(acc);
		else
			msg = "Account not found";
		return msg;
	}
	@Override
	public String creditMoney(long acc, long amt) {
		String msg;
		if(dao.findAccount(acc))
		 msg = dao.creditMoney(acc, amt);
		else
			msg = "Account not found";
		return msg;
	}
	@Override
	public String debitMoney(long acc, long amt) {
		String msg;
		if(dao.findAccount(acc)) {
		if(dao.getBalance(acc) < amt)
			msg = "Not enough fund present in account";
		else
		  msg = dao.debitMoney(acc, amt);
		}
		else
			msg = "Account not found";
		return msg;
	}
	@Override
	public String transferFunds(long sender, long reciver, long amt) {
		String msg;
		if(dao.findAccount(sender) && dao.findAccount(reciver)) {
		if(dao.getBalance(sender) < amt)
			msg = "Not enough fund present in account";
		else
		  msg = dao.transferFunds(sender, reciver, amt);
		}
		else
			msg = "Account not found";
		return msg;
	}
	@Override
	public List<Transactions> showTransaction(long acc) {
		
		if(dao.findAccount(acc))
	return	dao.showTransaction(acc);
		else {
			List<Transactions> li = null;
			System.out.println("Account not found");
			return li;
		}
		
		
		
	}
	

}
