package com.cg.service;

import java.util.List;

import com.cg.bean.SumBank;
import com.cg.bean.Transactions;

public interface SumServiceInter {

	
	public String createAccount(SumBank sum);
	public String viewBalance(long acc);
	public String creditMoney(long acc, long amt);
	public String debitMoney(long acc, long amt);
	public String transferFunds(long sender, long reciver, long amt);
	 public List<Transactions> showTransaction(long acc);
}
